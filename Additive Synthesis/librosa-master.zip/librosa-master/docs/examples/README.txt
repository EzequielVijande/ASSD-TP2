-----------------
Advanced examples
-----------------
