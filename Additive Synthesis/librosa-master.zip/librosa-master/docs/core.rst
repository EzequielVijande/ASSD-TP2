.. _core:

.. automodule:: librosa.core
