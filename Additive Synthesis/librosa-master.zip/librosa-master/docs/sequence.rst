.. _sequence:

.. automodule:: librosa.sequence
