.. _advanced:

.. toctree::
   :maxdepth: 2

.. include:: auto_examples/index.rst
